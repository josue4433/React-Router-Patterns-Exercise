import React from 'react';
import { useParams, Redirect } from 'react-router-dom';

const ColorDetails = ({ colors }) => {
  const { color } = useParams();
  const colorExists = colors.includes(color);

  if (!colorExists) {
    return <Redirect to="/colors" />;
  }

  return (
    <div>
      <h1>{color}</h1>
      <div style={{ backgroundColor: color, width: '200px', height: '200px' }}></div>
    </div>
  );
};

export default ColorDetails;
