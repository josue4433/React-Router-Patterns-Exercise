import React, { useState } from 'react';
import { useHistory } from 'react-router-dom';

const ColorForm = ({ handleAddColor }) => {
  const [color, setColor] = useState('');
  const history = useHistory();

  const handleSubmit = (e) => {
    e.preventDefault();
    handleAddColor(color);
    history.push('/colors');
  };

  return (
    <div>
      <h1>Add a Color</h1>
      <form onSubmit={handleSubmit}>
        <input type="color" value={color} onChange={(e) => setColor(e.target.value)} required />
        <button type="submit">Add Color</button>
      </form>
    </div>
  );
};

export default ColorForm;
