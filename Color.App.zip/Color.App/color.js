import React, { useState } from 'react';
import { Switch, Route, Redirect } from 'react-router-dom';
import ColorList from './ColorList';
import ColorDetails from './ColorDetails';
import ColorForm from './ColorForm.js';

const App = () => {
  const [colors, setColors] = useState([]);

  const handleAddColor = (newColor) => {
    setColors((prevColors) => [newColor, ...prevColors]);
  };

  return (
    <div>
      <Switch>
        <Route exact path="/colors">
          <ColorList colors={colors} />
        </Route>
        <Route exact path="/colors/new">
          <ColorForm handleAddColor={handleAddColor} />
        </Route>
        <Route exact path="/colors/:color">
          <ColorDetails colors={colors} />
        </Route>
        <Redirect to="/colors" />
      </Switch>
    </div>
  );
};

export default App;
